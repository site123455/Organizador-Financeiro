import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js";
import { getDatabase, ref, push, onValue, remove } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyC59lD35NPP7NnF37JZdHioX5ZQFtH1x18",
  authDomain: "organizacao-financeira-22cbd.firebaseapp.com",
  databaseURL: "https://organizacao-financeira-22cbd-default-rtdb.firebaseio.com",
  projectId: "organizacao-financeira-22cbd",
  storageBucket: "organizacao-financeira-22cbd.firebasestorage.app",
  messagingSenderId: "1094597462153",
  appId: "1:1094597462153:web:92bbb8b9ccc43f4732de58"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

const form = document.getElementById('form-transacao');
const lista = document.getElementById('lista-transacoes');
const ganhosEl = document.getElementById('ganhos');
const despesasEl = document.getElementById('despesas');
const saldoEl = document.getElementById('saldo');
const ctx = document.getElementById('grafico').getContext('2d');

let transacoes = [];

let grafico = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: [],
    datasets: [{
      label: 'Distribuição por Categoria',
      data: [],
      backgroundColor: ['#4CAF50','#FF6384','#36A2EB','#FFCE56','#8E44AD','#E67E22']
    }]
  }
});

function formatar(valor){
  return valor.toLocaleString('pt-BR', {style:'currency', currency:'BRL'});
}

function atualizarResumo() {
  let ganhos = transacoes.filter(t => t.tipo === 'ganho').reduce((acc,t)=>acc+t.valor,0);
  let despesas = transacoes.filter(t => t.tipo === 'despesa').reduce((acc,t)=>acc+t.valor,0);
  let saldo = ganhos - despesas;
  ganhosEl.textContent = `Ganhos: ${formatar(ganhos)}`;
  despesasEl.textContent = `Despesas: ${formatar(despesas)}`;
  saldoEl.textContent = `Saldo: ${formatar(saldo)}`;
}

function atualizarLista() {
  lista.innerHTML = "";
  transacoes.forEach((t) => {
    let tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${t.tipo}</td>
      <td>${t.descricao}</td>
      <td>${t.categoria}</td>
      <td>${formatar(t.valor)}</td>
    `;
    let btn = document.createElement('button');
    btn.textContent = '❌';
    btn.addEventListener('click', () => remover(t.id));
    let td = document.createElement('td');
    td.appendChild(btn);
    tr.appendChild(td);
    lista.appendChild(tr);
  });
}

function atualizarGrafico() {
  let categorias = {};
  transacoes.forEach(t => {
    if(t.tipo === 'despesa'){
      categorias[t.categoria] = (categorias[t.categoria] || 0) + t.valor;
    }
  });
  grafico.data.labels = Object.keys(categorias);
  grafico.data.datasets[0].data = Object.values(categorias);
  grafico.update();
}

function salvarFirebase(transacao){
  push(ref(db, 'transacoes'), transacao);
}

form.addEventListener('submit', e => {
  e.preventDefault();
  let tipo = document.getElementById('tipo').value;
  let descricao = document.getElementById('descricao').value;
  let valor = parseFloat(document.getElementById('valor').value);
  let categoria = document.getElementById('categoria').value;

  let transacao = {tipo, descricao, valor, categoria};
  salvarFirebase(transacao);
  form.reset();
});

function remover(id){
  remove(ref(db, 'transacoes/' + id));
}

onValue(ref(db, 'transacoes'), (snapshot) => {
  const data = snapshot.val() || {};
  transacoes = Object.entries(data).map(([id,t]) => ({id, ...t}));
  atualizarResumo();
  atualizarLista();
  atualizarGrafico();
});